/* 
standard functions 
*/
__declspec(dllimport) int Jail();
__declspec(dllimport) void reset();
__declspec(dllimport) void setChar(char *, char);
__declspec(dllimport) char getChar(char *);
__declspec(dllimport) void setInt(char *, int);
__declspec(dllimport) int getInt(char *);
__declspec(dllimport) void setDouble(char *, double);
__declspec(dllimport) double getDouble(char *);
__declspec(dllimport) void setString(char *, char *);
__declspec(dllimport) char* getString(char *);
__declspec(dllimport) int interpret(char *code);
__declspec(dllimport) char* getLastError();

/* 
Function loader 
*/

// Does return a value and takes 0 parameter
__declspec(dllimport) void *setNVCallBack(char *, void* (*funcPtr)());

// Does return a value and takes 1 parameter
__declspec(dllimport) void *setNVVCallBack(char *, void* (*funcPtr)(void *));

// Does return a value and takes 2 parameter
__declspec(dllimport) void *setNVVVCallBack(char *, void* (*funcPtr)(void *, void *));

// Does return a value and takes 3 parameter
__declspec(dllimport) void *setNVVVVCallBack(char *, void* (*funcPtr)(void *, void *, void *));

// Does NOT return a value and takes 1 parameter
__declspec(dllimport) void *setVVCallBack(char *, void (*funcPtr)(void *));