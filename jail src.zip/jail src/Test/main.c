#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h> // getch()

#include "Jail.h"

int getchar();

void print(void* data) {    

    printf("%s", (char *)data);    
    
}

void* read() {
    
    char str[] = "";
    sprintf(str, "%d", getch());
    return (void *)strdup(str);

}

void* readline() {    

    char *str = NULL;    
    size_t len = 1024;    
    getline(&str, &len, stdin);    
    str[strlen(str)-1] = '\0';    
    return (void *)str;   
     
}

char* readCode(char* file) {
    // read text file with code    
    FILE* f;
    f = fopen(file, "r");
    fseek(f, 0L, SEEK_END); 
    int len = ftell(f); 
    rewind(f);
    char c, buffer[len];    
    int i = 0;
    while( fread(&c, sizeof(char), 1, f) > 0 ) 
        buffer[i++] = c;
    fclose(f);
    buffer[i] = '\0';
    return strdup(buffer);
}

int main(int argc, char **argv) {

    Jail();
    reset();
    
    setVVCallBack("print", print);    
    setNVCallBack("read", read);
    setNVCallBack("readline", readline);

    char* code = readCode(argv[1]);
    
    int res = interpret(code);
    
    if(!res)
        printf("%s", getLastError());
        
    return 0;

}