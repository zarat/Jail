#include "Jail.h"

#include <sys/time.h>

namespace JAIL {

void scMathRand(JObject *c, void *) {
    struct timeval tvTime;
    gettimeofday(&tvTime, NULL);
    int iTotal_seconds = tvTime.tv_sec;
    struct tm *ptm = localtime((const time_t *) & iTotal_seconds);    
    srand ((int)tvTime.tv_usec);
    c->getReturnVar()->setInt(rand());
}

void scMathRandInRange(JObject *c, void *) {
    int min = c->getParameter("min")->getInt();
    int max = c->getParameter("max")->getInt();    
    struct timeval tvTime;
    gettimeofday(&tvTime, NULL);
    int iTotal_seconds = tvTime.tv_sec;
    struct tm *ptm = localtime((const time_t *) & iTotal_seconds);    
    srand ((int)tvTime.tv_usec);
    int val = min + (int)( rand() % (1 + (max - min) ) );
    c->getReturnVar()->setInt(val);
}

/*
void scCharToInt(JObject *c, void *) {
    std::string str = c->getParameter("ch")->getString();;
    int val = 0;
    if (str.length()>0)
        val = (int)str.c_str()[0];
    c->getReturnVar()->setInt(val);
}
*/

void scIntegerParseInt(JObject *c, void *) {
    if(c->getParameter("str")->isString()) {
        std::string str = c->getParameter("str")->getString();
        int val = strtol(str.c_str(), 0, 0);
        c->getReturnVar()->setInt( val );
    }
    else if(c->getParameter("str")->isDouble()) {
        std::string s = std::to_string( c->getParameter("str")->getDouble() );
        int i = strtol( s.c_str(), 0, 0 );
        c->getReturnVar()->setInt( i );
    }
    else if(c->getParameter("str")->isInt()) {
        int str = c->getParameter("str")->getInt();
        c->getReturnVar()->setInt(str);
    }
    else if(c->getParameter("str")->isChar()) {
        int str = c->getParameter("str")->getChar();
        c->getReturnVar()->setInt(str);
    }
    else
        c->getReturnVar()->setUndefined();
}

void registerInteger(JInterpreter *interpreter) {

    interpreter->addNative("function Integer.rand()", scMathRand, 0);
    interpreter->addNative("function Integer.range(min, max)", scMathRandInRange, 0);    
    //interpreter->addNative("function Integer.fromChar(ch)", scCharToInt, 0);
    interpreter->addNative("function Integer.parse(str)", scIntegerParseInt, 0); // string to int

}

}