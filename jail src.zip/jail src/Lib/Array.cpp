/*

Function array.each() has a bug, everything is a string..

*/

#include "Jail.h"
#include <sstream>

namespace JAIL {

void scArrayContains(JObject *c, void *data) {
  JObject *obj = c->getParameter("obj"); // the obj to search for
  JLink *v = c->getParameter("this")->firstChild; // the array
  bool contains = false;
  while (v) {
      if (v->var->equals(obj)) {
        contains = true;
        break;
      }
      v = v->nextSibling;
  }
  c->getReturnVar()->setInt(contains);
}

// returns a new array
void scArrayRemove(JObject *c, void *data) {

  JObject *self = c->getParameter("this");
  JObject *obj = c->getParameter("obj");  
  JObject *result = new JObject();
  result->setArray();  
  JLink *v = self->firstChild;
  int i = 0;
  while (v) {  
      if (!v->var->equals(obj)) {        
        result->setArrayIndex(i, v->var);        
        i++;
      }
      v = v->nextSibling;
  }    
  c->setReturnVar(result);
    
}

void scArrayJoin(JObject *c, void *data) {
  std::string sep = c->getParameter("separator")->getString();
  JObject *arr = c->getParameter("this");
  std::ostringstream sstr;
  int l = arr->getArrayLength();
  for (int i=0;i<l;i++) {
    if (i>0) sstr << sep;
    sstr << arr->getArrayIndex(i)->getString();
  }
  c->getReturnVar()->setString(sstr.str());
}

void scArrayCount(JObject *c, void *data) {
    JObject *arr = c->getParameter("this");
    int l = arr->getArrayLength();
    c->getReturnVar()->setInt(l);
}

// 
void scArrayEach(JObject *c, void *data) {    
    JObject *arr = c->getParameter("this");
    std::string func = c->getParameter("func")->getString();
    int l = arr->getArrayLength();    
    for (int i = 0; i < l; i++) {        
        JInterpreter *interpreter = reinterpret_cast<JInterpreter *>(data);
        std::stringstream ss;
        ss << "var e = \"" << arr->getArrayIndex(i)->getString() << "\"; " << func;
        interpreter->execute(ss.str()); 
    }
    c->getReturnVar()->setInt(l);    
}

// todo
// shift first out, returns new array
void scArrayShift(JObject *c, void *data) {        
    JObject *self = c->getParameter("this");
    JObject *obj = c->getParameter("obj");  
    JObject *result = new JObject();
    result->setArray();  
    JLink *v = self->firstChild;
    int i = 0, j = 0;
    while (v) {  
        if (j > 0) {        
          result->setArrayIndex(i, v->var);        
          i++;
        }
        j++;
        v = v->nextSibling;
    }    
    c->setReturnVar(result);         
}

// todo
// returns a new array
void scArrayReverse(JObject *c, void *data) {    
    JObject *obj = c->getParameter("this");    
    JObject *result = new JObject();
    result->setArray();    
    int i = obj->getArrayLength()-1;
    JLink *link = obj->firstChild;        
    while(link) {
        result->setArrayIndex(i--, link->var);
        link = link->nextSibling;
    }    
    c->setReturnVar(result);    
}
    
    void registerArray(JInterpreter *interpreter) {
    
        interpreter->addNative("function Array.contains(obj)", scArrayContains, 0);
        interpreter->addNative("function Array.remove(obj)", scArrayRemove, 0);
        interpreter->addNative("function Array.join(separator)", scArrayJoin, 0);
        interpreter->addNative("function Array.count()", scArrayCount, 0);
        interpreter->addNative("function Array.each(func)", scArrayEach, interpreter);
        interpreter->addNative("function Array.shift()", scArrayShift, 0);
        interpreter->addNative("function Array.reverse()", scArrayReverse, 0);
        
    }

}