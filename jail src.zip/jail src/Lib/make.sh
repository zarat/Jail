g++ -c Jail.cpp main.cpp 
g++ -shared Jail.o main.o -o jail.so