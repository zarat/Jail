#define _WIN32_WINNT 0x501

#include "Jail_Functions.h"

#include <iostream>
#include <fstream>
#include <sys/time.h>

#include <string>
#include <string.h>

#include <conio.h> // getch()
#include <iomanip> // base64
#include <map>
//#include <regex>



namespace JAIL {

struct OpenFile {
    FILE * file;
};

std::map<int, OpenFile> openFiles;

    //struct OpenFile { FILE *file; };
    
    //std::map<int, OpenFile> openFiles;
    
    static std::string base64_encode(const std::string &in) {
        std::string out;
        int val=0, valb=-6;
        for (char c : in) {
            val = (val<<8) + c;
            valb += 8;
            while (valb>=0) {
                out.push_back("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[(val>>valb)&0x3F]);
                valb-=6;
            }
        }
        if (valb>-6) out.push_back("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[((val<<8)>>(valb+8))&0x3F]);
        while (out.size()%4) out.push_back('=');
        return out;
    }
    
    static std::string base64_decode(const std::string &in) {
        std::string out;
        std::vector<int> T(256,-1);
        for (int i=0; i<64; i++) T["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"[i]] = i; 
        int val=0, valb=-8;
        for (char c : in) {
            if (T[c] == -1) break;
            val = (val<<6) + T[c];
            valb += 6;
            if (valb>=0) {
                out.push_back(char((val>>valb)&0xFF));
                valb-=8;
            }
        }
        return out;
    }
    
    // ----------------------------------------------- Actual Functions
    
    /**
     * typeOf()
     */
    void scTypeOf(JObject *c, void *) {
        JObject *v = c->getParameter("v");
        if(v->isObject())
            c->getReturnVar()->setString("object"); 
        else if(v->isFunction())
            c->getReturnVar()->setString("function");
        else if(v->isArray())
            c->getReturnVar()->setString("array");
        else if(v->isString())
            c->getReturnVar()->setString("string");
        else if(v->isDouble())
            c->getReturnVar()->setString("double");
        else if(v->isInt())
            c->getReturnVar()->setString("int");
        else if(v->isChar())
            c->getReturnVar()->setString("char");
        else if(v->isNull())
            c->getReturnVar()->setString("null");
        else if(v->isUndefined())
            c->getReturnVar()->setString("undefined");
        else if(v->isNative())
            c->getReturnVar()->setString("native");  
    }

    /*
    void scConsoleRead(JObject *c, void *) {   
        int ch;
        ch = getch();
        c->getReturnVar()->setInt(ch);
    } 

    void scConsoleReadLine(JObject *c, void *) {   
        std::string str; 
        std::getline(std::cin, str);
        if(c->getParameter("this")->isObject()) {
            JLink *v = c->getParameter("this")->firstChild;
            while(v) {           
                if(v->name.compare("value") == 0) {            
                    v->var->setString(str.c_str());
                    break;                
                }            
                v = v->nextSibling;            
            }            
        }
        else 
            c->getReturnVar()->setString(str.c_str());
    }

    void scConsoleWrite(JObject *c, void *) {   
        if(c->getParameter("str")->isArray() || c->getParameter("str")->isFunction()) {    
            std::ostringstream oss;
            c->getParameter("str")->getJSON(oss);
            std::cout << oss.str();
            c->getReturnVar()->setString(oss.str());   
        }         
        else if(c->getParameter("str")->isObject()) {
            JLink *v = c->getParameter("str")->firstChild;
            while(v) {           
                if(v->name.compare("value") == 0) {            
                    std::cout << v->var->getString();
                    break;                
                }            
                v = v->nextSibling;            
            }    
        }        
        else {    
            std::string str = c->getParameter("str")->getString(); 
            std::cout << str;
            c->getReturnVar()->setString(str.c_str());            
        }        
    }
    
    void scConsoleWriteByte(JObject *c, void *) {      
        if(c->getParameter("ch")->isObject()) {
            JLink *v = c->getParameter("ch")->firstChild;
            while(v) {           
                if(v->name.compare("value") == 0) {            
                    std::cout << v->var->getChar();
                    break;                
                }            
                v = v->nextSibling;            
            }            
        } else {  
            std::cout << c->getParameter("ch")->getChar();
        }    
    }
    */
    
    // system() 
    void scProcessExec(JObject *c, void *) {
        char buffer[128];
        std::string result = "";
        std::string cmd = c->getParameter("cmd")->getString();
        FILE* pipe = popen(cmd.c_str(), "r");
        if (!pipe) 
            throw new JAIL::Exception("Cannot read/write to system process.");
        try {
            while (fgets(buffer, sizeof buffer, pipe) != NULL) {
                result += buffer;
            }
        } catch (...) {
            pclose(pipe);
            throw new JAIL::Exception("Cannot read/write to system process.");
        }
        pclose(pipe);
        c->getReturnVar()->setString(result);
    }
    
    /** 
     * getEnv(str)
     * get environment JObject
     * using a stringstream to ensure no empty data
     */
    void scGetEnv(JObject *c, void *) {
        std::stringstream ss;
        ss << getenv(c->getParameter("str")->getString().c_str());
        c->getReturnVar()->setString(ss.str());
    }
    
    /**
     * setEnv() 
     * set environment JObject
     */
    void scSetEnv(JObject *c, void *) {
        std::string k = c->getParameter("k")->getString();
        std::string v = c->getParameter("v")->getString();
        setenv(k.c_str(), v.c_str(), 1); // 1 for overwrite
        c->getReturnVar()->setInt(1);
    }
    
    /** 
     * get time as array (hour, min, sec, millisec, microsec)
     */
    void scSystemTime(JObject *c, void *) {       
        struct timeval tvTime;
        gettimeofday(&tvTime, NULL);
        int iTotal_seconds = tvTime.tv_sec;
        struct tm *ptm = localtime((const time_t *) & iTotal_seconds);
        JObject *v = new JObject();
        v->setArray();
        v->setArrayIndex(0, new JObject((int)ptm->tm_hour));
        v->setArrayIndex(1, new JObject((int)ptm->tm_min));
        v->setArrayIndex(2, new JObject((int)ptm->tm_sec));
        v->setArrayIndex(3, new JObject((int)tvTime.tv_usec / 1000));
        v->setArrayIndex(4, new JObject((int)tvTime.tv_usec));
        c->getReturnVar()->setArray(v->getArray());        
    }
    
    /*
    void scReadFile(JObject *c, void *) {    
        int src = c->getParameter("src")->getInt();
        FILE *f;
        if(openFiles[src].file) {
            f = openFiles[src].file;   
            fseek (f , 0 , SEEK_END);
            long lSize = ftell (f);
            rewind (f);    
            char *buffer = (char*)malloc(sizeof(char)*lSize+1);
            buffer[lSize] = '\0';
            fread(buffer, sizeof(char), lSize, f);
            c->getReturnVar()->setString(buffer);   
        }
        else
            c->getReturnVar()->setString("");        
    }

    void scReadFileToCharArray(JObject *c, void *) {    
        int src = c->getParameter("src")->getInt();
        FILE *f;
        if(openFiles[src].file) {
            f = openFiles[src].file;   
            fseek (f , 0 , SEEK_END);
            long lSize = ftell (f);
            rewind (f);    
            char *buffer = (char*)malloc(sizeof(char)*lSize+1);
            buffer[lSize] = '\0';
            fread(buffer, sizeof(char), lSize, f);        
            JObject *result = c->getReturnVar();
            int i = 0;
            while(i < lSize) {
                result->setArrayIndex(i, new JObject((int)buffer[i]));
                i++;
            }      
        }         
    }

    void scWriteFile(JObject *c, void *) {
        int src = c->getParameter("src")->getInt();
        std::string content = c->getParameter("data")->getString();    
        FILE *f;
        if(openFiles[src].file) {
            f = openFiles[src].file;   
            fwrite(content.c_str(), sizeof(char), strlen(content.c_str()), f);
            c->getReturnVar()->setInt(1);   
        }
        else
            c->getReturnVar()->setInt(0);             
    }

    void scOpenFile(JObject *c, void *) {    
        std::string filename = c->getParameter("src")->getString();
        std::string mode = c->getParameter("mode")->getString();
        FILE *f;
        if(f = fopen(filename.c_str(), mode.c_str())) {
            struct OpenFile of = { f };
            int curr = openFiles.size();
            openFiles[curr] = of;
            c->getReturnVar()->setInt(curr); 
        }
        else
            c->getReturnVar()->setInt(-1);              
    }

    void scCloseFile(JObject *c, void *) {    
        int fileIndex = c->getParameter("src")->getInt();
        fclose(openFiles[fileIndex].file);
        openFiles.erase(fileIndex);         
    }
    */
    
    /**
     * import()
     * import, read and eval file from disk
     */
    void scImportFile(JObject *c, void *data) {    
        JInterpreter *JInterpreter = reinterpret_cast<JAIL::JInterpreter *>(data);
        std::string filename = c->getParameter("src")->getString();
        std::ifstream readfile(filename);
        std::string line;
        if(readfile.is_open()) {
            std::stringstream ss;
            while(getline(readfile, line)) 
                ss << line.c_str() << "\n";
            std::string code = ss.str().c_str();
            JInterpreter->execute(code);       
            readfile.close();        
        }             
    }
    
    /*
    void scJSONStringify(JObject *c, void *) {
        std::ostringstream result;
        c->getParameter("obj")->getJSON(result);
        c->getReturnVar()->setString(result.str());
    }
    */
    
    /*
    void scRegex(JObject *c, void *) {    
        std::string var = c->getParameter("data")->getString();
    	const std::regex r(c->getParameter("regex")->getString());  
    	std::smatch sm;
        JObject *result = c->getReturnVar();  
        result->setArray();
    	int i = 0;
        while(regex_search(var, sm, r)) {
    		result->setArrayIndex(i, new JObject(sm[0], VARIABLE_STRING));        
            i++;
            var = sm.suffix().str();
        }
    }
    */
    
    void scBase64Encode(JObject *c, void *) {
        std::string var = c->getParameter("data")->getString();
        c->getReturnVar()->setString(base64_encode(var));    
    }
    
    void scBase64Decode(JObject *c, void *) {
        std::string var = c->getParameter("data")->getString();
        c->getReturnVar()->setString(base64_decode(var));
    }
    
    void scMd5(JObject *c, void *data) { 
        std::string var = c->getParameter("data")->getString();
        std::stringstream md5string;
        md5string << std::hex << std::uppercase << std::setfill('0');
        for (const auto &byte: var)
            md5string << std::setw(2) << (int)byte;
        c->getReturnVar()->setString(md5string.str().c_str());
    }
    
    void scExec(JObject *c, void *data) {
        JInterpreter *tinyJS = (JInterpreter *)data;
        std::string str = c->getParameter("jsCode")->getString();
        tinyJS->execute(str);
    }
    
    void scEval(JObject *c, void *data) {
        JInterpreter *tinyJS = (JInterpreter *)data;
        std::string str = c->getParameter("jsCode")->getString();
        c->setReturnVar(tinyJS->evaluateComplex(str).var);
    }
    
    void scOpenFile(JObject *c, void *data) {
        std::string filename = c->getParameter("src")->getString().c_str();
        std::string mode = c->getParameter("mode")->getString().c_str();
        
        FILE *f;
        std::string r;
        
        if(f = fopen(filename.c_str(), mode.c_str())) {
            struct OpenFile of { f };
            int idx = openFiles.size();
            openFiles[idx] = of;
            r = std::to_string(idx);      
        }
        else
            r = std::to_string(-1);
        c->getReturnVar()->setString(r.c_str());
    }
    
    void scReadFile(JObject *c, void *data) {

        int fileindex = std::stoi(c->getParameter("src")->getString());
        OpenFile _f = openFiles[fileindex];
        FILE *f = _f.file;
        fseek(f, 0L, SEEK_END); 
        int len = ftell(f); 
        rewind(f);
        char ch, buf[len];    
        int i = 0;
        while( fread(&ch, sizeof(char), 1, f) > 0 ) 
            buf[i++] = ch;
        buf[i++] = '\0';        
        c->getReturnVar()->setString(buf);
        
    }
    
    void scWriteFile(JObject *c, void *data) {
    
        int fileindex = std::stoi(c->getParameter("src")->getString());
        std::string content = c->getParameter("data")->getString();   
        OpenFile _f = openFiles[fileindex];
        FILE *f = _f.file;
        // todo: error handling!
        fwrite(content.c_str(), sizeof(char), strlen(content.c_str()), f); 
        c->getReturnVar()->setInt(1);
        
    }
    
    void scCloseFile(JObject *c, void *data) {
    
        int fileindex = std::stoi(c->getParameter("src")->getString());
        FILE *f = openFiles[fileindex].file;
        fclose(f); 
        // todo: error handling
        openFiles.erase(fileindex);
        std::string r = std::to_string(1);
        c->getReturnVar()->setString(r.c_str());
        
    }
    
    void registerFunctions(JAIL::JInterpreter *interpreter) {
    
        // input/output
        /*
        interpreter->addNative("function read()", scConsoleRead, 0);
        interpreter->addNative("function readLine()", scConsoleReadLine, 0);
        interpreter->addNative("function print(str)", scConsoleWrite, 0);
        interpreter->addNative("function printc(ch)", scConsoleWriteByte, 0);
        */
        
        // working with files
        
        interpreter->addNative("function fopen(src, mode)", scOpenFile, 0);
        interpreter->addNative("function fread(src)", scReadFile, 0);
        interpreter->addNative("function fwrite(src, data)", scWriteFile, 0);
        interpreter->addNative("function fclose(src)", scCloseFile, 0);
        

        interpreter->addNative("function system(cmd)", scProcessExec, 0);
        interpreter->addNative("function getEnv(str)", scGetEnv, 0);
        interpreter->addNative("function setEnv(k, v)", scSetEnv, 0);    
        interpreter->addNative("function time()", scSystemTime, 0);
        interpreter->addNative("function typeOf(v)", scTypeOf, interpreter);
        interpreter->addNative("function import(src)", scImportFile, interpreter);
        //interpreter->addNative("function JSON.stringify(obj)", scJSONStringify, 0);    
        interpreter->addNative("function parse(jsCode)", scEval, interpreter);        
        //interpreter->addNative("function regex(data, regex)", scRegex, 0); // read JSON
        interpreter->addNative("function atob(data)", scBase64Encode, 0);
        interpreter->addNative("function btoa(data)", scBase64Decode, 0);
        interpreter->addNative("function md5(data)", scMd5, 0);
    
    }

};