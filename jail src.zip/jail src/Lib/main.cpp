#include "Jail.h"
#include "DataTypes.h"
#include "Jail_Functions.h"

#include <sstream>
#include <fstream>
#include <map>
#include <windows.h> 
#include <stdio.h>

using namespace std;

void eval(JAIL::JObject *c, void *data) {
    JAIL::JInterpreter *interpreter = reinterpret_cast<JAIL::JInterpreter *>(data);
    std::string code = c->getParameter("code")->getString();
    interpreter->execute(code);       
}

void debug(JAIL::JObject *c, void *data) {
    std::ostringstream oss;
    c->getParameter("a")->getJSON(oss);
    c->getReturnVar()->setString(oss.str());       
}





    int main(int argc, char **argv) {                         
  
        JAIL::JInterpreter interpreter;
        char *lastError;

        registerChar(&interpreter); 
        registerInteger(&interpreter);
        registerDouble(&interpreter);
        registerString(&interpreter);
        registerObject(&interpreter);
        registerArray(&interpreter);
        registerFunctions(&interpreter); 
            
        interpreter.addNative("function jail.eval(code)", eval, &interpreter);
        interpreter.addNative("function jail.debug(a)", debug, &interpreter);

        try {
            interpreter.execute(code);
        } catch (JAIL::Exception *e) { 
            lastError = (char *)e->text.c_str();
            return 0;
        } 
        return 1;                     
    }
    
   