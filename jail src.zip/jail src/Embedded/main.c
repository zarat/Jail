#include <stdio.h> 
#include <dirent.h>
#include <string.h>
#include <stdlib.h>

#include <unistd.h>
#include <stdio.h>
#include <limits.h>
#include <shlwapi.h> // use -lshlwapi
#include <conio.h>

#ifdef _WIN32
#include <windows.h>
typedef HANDLE lib_t;
#else
#include <dlfcn.h>
typedef void* lib_t;
#endif

// function signatures from jail.dll 
typedef int (__cdecl *JAILPROC)(char *); // Jail, interpret
 
// jail.getLastError()
typedef char* (__cdecl *GETLASTERRORPROC)();

// constructor from libs
typedef char* (__cdecl *EXTCONSTRUCTOR)();

lib_t dll; //HINSTANCE dll; // jail.dll 
JAILPROC func; // Jail.Jail(), jail.interpret() 
GETLASTERRORPROC errorfunc; // Jail.getLastError() 
 

void loadVV(char *a, char *b) {
    lib_t ext_dll = NULL;
    #ifdef _WIN32
    ext_dll = LoadLibrary(a);
    #else
    ext_dll = dlopen(a, RTLD_LAZY);
    #endif
    if(NULL != ext_dll) {       
        #ifdef _WIN32
        ( GetProcAddress(dll, "setVVCallBack") )(b, GetProcAddress(ext_dll, b) );
        #else
        ( dlsym(dll, "setVVCallBack") )(b, dlsym(ext_dll, b) );
        #endif
    }            
}

void loadNV(char *a, char *b) {
    lib_t ext_dll = NULL;
    #ifdef _WIN32
    ext_dll = LoadLibrary(a);
    #else
    ext_dll = dlopen(a, RTLD_LAZY);
    #endif
    if(NULL != ext_dll) {       
        #ifdef _WIN32
        ( GetProcAddress(dll, "setNVCallBack") )(b, GetProcAddress(ext_dll, b) );
        #else
        ( dlsym(dll, "setNVCallBack") )(b, dlsym(ext_dll, b) );
        #endif
    } 
}

void loadNVV(char *a, char *b) {
    lib_t ext_dll = NULL;
    #ifdef _WIN32
    ext_dll = LoadLibrary(a);
    #else
    ext_dll = dlopen(a, RTLD_LAZY);
    #endif
    if(NULL != ext_dll) {       
        #ifdef _WIN32
        ( GetProcAddress(dll, "setNVVCallBack") )(b, GetProcAddress(ext_dll, b) );
        #else
        ( dlsym(dll, "setNVVCallBack") )(b, dlsym(ext_dll, b) );
        #endif
    }
}

void loadNVVV(char *a, char *b) {
    lib_t ext_dll = NULL;
    #ifdef _WIN32
    ext_dll = LoadLibrary(a);
    #else
    ext_dll = dlopen(a, RTLD_LAZY);
    #endif
    if(NULL != ext_dll) {       
        #ifdef _WIN32
        ( GetProcAddress(dll, "setNVVVCallBack") )(b, GetProcAddress(ext_dll, b) );
        #else
        ( dlsym(dll, "setNVVVCallBack") )(b, dlsym(ext_dll, b) );
        #endif
    }
}

void loadNVVVV(char *a, char *b) {
    lib_t ext_dll = NULL;
    #ifdef _WIN32
    ext_dll = LoadLibrary(a);
    #else
    ext_dll = dlopen(a, RTLD_LAZY);
    #endif
    if(NULL != ext_dll) {       
        #ifdef _WIN32
        ( GetProcAddress(dll, "setNVVVVCallBack") )(b, GetProcAddress(ext_dll, b) );
        #else
        ( dlsym(dll, "setNVVVVCallBack") )(b, dlsym(ext_dll, b) );
        #endif
    }
}

void error_exit(char *msg) {
    fprintf(stderr, "error: %s", msg);
    exit(1);
}

// todo
// rewrite for linux
void loadExtensionDlls() {
    
    char selfdir[128] = {0}; 
    
    #ifdef _WIN32 
    // Retrieves the fully qualified path
    GetModuleFileNameA(NULL, selfdir, 128);    
    // Removes the trailing file name and backslash from a path, if they are present.
    PathRemoveFileSpecA(selfdir);    
    sprintf(selfdir, "%s\\libs\\", selfdir);
    #else
    getcwd(selfdir, sizeof(selfdir));
    sprintf(selfdir, "%s/libs/", selfdir);
    #endif
    
    DIR *d;
    struct dirent *dir;    
    d = opendir(selfdir);
    
    if (d) {
    
        while ((dir = readdir(d)) != NULL) {
        
            // split into (name, extension)
            char *tmp = dir->d_name;           
            char *tok = strtok(tmp, ".");
            if(NULL == tok)
                continue;                                
            char *filename = tok;
            tok = strtok(NULL, ".");
            char *fileext = tok;
            
            //skip jail.dll, maybe &&
            #ifdef _WIN32
            if(strcmp(fileext, "dll") != 0 || strcmp(filename, "jail") == 0)
                continue;
            #else
            if(strcmp(fileext, "so") != 0 || strcmp(filename, "jail") == 0)
                continue;
            #endif
                
            char cmp[128] = {0};           
            #ifdef _WIN32
            sprintf(cmp, "%s%s.dll", selfdir, dir->d_name);
            #else
            sprintf(cmp, "%s%s.so", selfdir, dir->d_name);
            #endif

            #ifdef _WIN32
            lib_t test_dll = LoadLibrary( cmp );
            #else
            lib_t test_dll = dlopen(a, RTLD_LAZY);
            #endif
            
            if(NULL != test_dll) {
        
                // get the exported functions from the constructor
                EXTCONSTRUCTOR pr = (EXTCONSTRUCTOR) GetProcAddress(test_dll, "__construct");                
                if(NULL == pr)  
                    continue; 
                char *exportedFunctions = (pr)();                      

                // strtok in a loop
                // https://stackoverflow.com/questions/4693884/nested-strtok-function-problem-in-c
                char *string = exportedFunctions;
                char *token  = strchr(string, ';');
                while (token != NULL) {
                
                    *token++ = '\0';
                    char *extensionName, *extensionSignature;                    
                    char *token2 = strtok(string, "_");
                    int i = 0;
                    while (token2 != NULL) {
                        if(i == 0)
                            extensionName = token2;
                        else if(i == 1)
                            extensionSignature = token2;
                        token2 = strtok(NULL, "_");
                        i++;
                    }                 

                    // load it
                    if(strcmp(extensionSignature, "vv") == 0) 
                        loadVV(cmp, extensionName);                    
                    if(strcmp(extensionSignature, "nv") == 0) 
                        loadNV(cmp, extensionName);                    
                    if(strcmp(extensionSignature, "nvv") == 0) 
                        loadNVV(cmp, extensionName);                    
                    if(strcmp(extensionSignature, "nvvv") == 0) 
                        loadNVVV(cmp, extensionName);                    
                    if(strcmp(extensionSignature, "nvvvv") == 0) 
                        loadNVVVV(cmp, extensionName);                    
                    
                    string = token;
                    token = strchr(string, ';');
                    
                }
                
            }
 
        }
        
    } 
    
}

int main( int argc, char **argv ) { 

    if(argc < 2)
    {
        printf("Usage: jail <file>");
        return 1;
    }

    // load jail library
    #ifdef _WIN32
    dll = LoadLibrary("jail.dll"); 
    #else
    dll = dlopen("jail.so", RTLD_LAZY);
    #endif   

    // init jail
    #ifdef _WIN32
    func = (JAILPROC) GetProcAddress(dll, "Jail");
    #else
    func = (JAILPROC) dlsym(dll, "Jail");
    #endif       
    (func);
    
    // load interpret function
    #ifdef _WIN32
    func = (JAILPROC) GetProcAddress(dll, "interpret");
    #else
    func = (JAILPROC) dlsym(dll, "interpret");
    #endif
    
    loadExtensionDlls();  
    
    // read text file with code    
    FILE* f;
    f = fopen(argv[1], "r");
    fseek(f, 0L, SEEK_END); 
    int len = ftell(f); 
    rewind(f);
    char c, buffer[len];    
    int i = 0;
    while( fread(&c, sizeof(char), 1, f) > 0 ) 
        buffer[i++] = c;
    fclose(f);
    buffer[i] = '\0';

    // execute the interpret function           
    int result = (func)(buffer); 
 
    // show errors if any
    if(!result) {
    
        #ifdef _WIN32
        errorfunc = (GETLASTERRORPROC) GetProcAddress(dll, "getLastError");
        #else
        errorfunc = (GETLASTERRORPROC) dlsym(dll, "getLastError");
        #endif
        
        char* buffer = (errorfunc)();        
        printf(buffer);
        
    }
        
    #ifdef _WIN32
    FreeLibrary(dll); 
    #else
    dlclose(dll);
    #endif
    
    return 0;

}