#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>

void change(char **a);
void change1(char *a);

int main()
{

    char *a = "hello";
    char b[] = "world";
    
    printf("a = %s, b = %s", a, b);
    
    change(&a);
    change1(b);
    
    printf("%\na = %s, b = %s", a, b);
    
    return 1;
    
}

void change(char **a)
{

    *a = "goodbye";
}

void change1(char *a)
{

    a = "goodbye";
}