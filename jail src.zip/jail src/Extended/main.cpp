#include "Jail.h"
#include <iostream>

using namespace JAIL;

void scPrint(JObject *o, void *data) {
   std::cout << o->getParameter("str")->getString();
}

void scRead(JObject *o, void *data) {
   
   // get a line
   char str[1024] = "";
   cin.getline(str, 1024);
   
   // get a word
   //std::string str;
   //std::cin >> str;
   
   o->getReturnVar()->setString(str);
   
}

int main(int argc, char **argv) {

    JInterpreter *interpreter = new JInterpreter();
    interpreter->addNative("function print(str)", scPrint, 0);
    interpreter->addNative("function read()", scRead, 0);
    
    FILE *f;
    f = fopen(argv[1], "r");
    fseek(f, 0L, SEEK_END); 
    int len = ftell(f); 
    rewind(f);
    char c, buffer[len];    
    int i = 0;
    while( fread(&c, sizeof(char), 1, f) > 0 ) buffer[i++] = c;
    fclose(f);
    buffer[i] = '\0';
   
    try {
        interpreter->execute(buffer);
    } catch(...) {
       
    }
    
    return 0;
    
}
